//
//  VPPeripheralManage.h
//  VPBleSdk
//
//  Created by 张冲 on 17/1/11.
//  Copyright © 2017年 veepoo. All rights reserved.
//

//Simple one-time read and use
// 简单一次性读取使用
#import "VPPeripheralBaseManage.h"

@interface VPPeripheralManage : VPPeripheralBaseManage

//
+ (instancetype)shareVPPeripheralManager;




@end







