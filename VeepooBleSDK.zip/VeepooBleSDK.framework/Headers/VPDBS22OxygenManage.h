//
//  VPDBS22OxygenManage.h
//  VeepooBleSDK
//
//  Created by 张冲 on 2019/10/15.
//  Copyright © 2019 veepoo. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface VPDBS22OxygenManage : NSObject

@end

NS_ASSUME_NONNULL_END
