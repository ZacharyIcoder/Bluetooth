//
//  VPPeripheralAddManage.h
//  VeepooBleSDK
//
//  Created by 张冲 on 17/9/20.
//  Copyright © 2017年 veepoo. All rights reserved.
//

//Custom read usage, data needs to be saved by itself
// 自定义读取使用
#import "VPPeripheralBaseManage.h"

@interface VPPeripheralAddManage : VPPeripheralBaseManage

+ (instancetype)shareVPPeripheralManager;



@end
