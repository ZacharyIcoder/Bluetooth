//
//  VPHRVHeaderCurveView.h
//  WYPHealthyThird
//
//  Created by 张冲 on 2017/11/6.
//  Copyright © 2017年 veepoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VPHRVCurveView : UIView

//传输从数据库获取某一天的hrv数据
@property (nonatomic, strong) NSArray *oneDayHrvs;

@end
