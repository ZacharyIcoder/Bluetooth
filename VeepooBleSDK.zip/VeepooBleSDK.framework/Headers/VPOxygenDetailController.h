//
//  VPOxygenDetailController.h
//  WYPHealthyThird
//
//  Created by 张冲 on 17/9/13.
//  Copyright © 2017年 veepoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VPOxygenDetailController : UIViewController

@property (nonatomic, assign) NSInteger showType;

@end
